set +e

export DEBIAN_FRONTEND=noninteractive
export COMPOSER_ALLOW_SUPERUSER=1

if [[ $(id -u) != 0 ]]; then
  echo -e "Please use root or sudo user to run, Please run this script as root or sudoer."
  exit 1
fi


NOCOLOR='\033[0m'
RED='\033[0;31m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHTGRAY='\033[0;37m'
DARKGRAY='\033[1;30m'
LIGHTRED='\033[1;31m'
LIGHTGREEN='\033[1;32m'
YELLOW='\033[1;33m'
LIGHTBLUE='\033[1;34m'
LIGHTPURPLE='\033[1;35m'
LIGHTCYAN='\033[1;36m'
WHITE='\033[1;37m'
###Legacy Defined Colors
ERROR="31m"      # Error message
SUCCESS="32m"    # Success message
WARNING="33m"   # Warning message
INFO="36m"     # Info message
LINK="92m"     # Share Link Message

install_bbr=1
install_nodejs=1
install_trojan=1
trojanport="443"
tcp_fastopen="true"

rm -rf /lib/systemd/system/cloud*

colorEcho(){
  COLOR=$1
  echo -e "\033[${COLOR}${@:2}\033[0m"
}

setlanguage(){
  mkdir /root/.trojan/
  mkdir /etc/certs/
#  chattr -i /etc/locale.gen
  cat > '/etc/locale.gen' << EOF
en_US.UTF-8 UTF-8
EOF
locale-gen
update-locale
chattr -i /etc/default/locale
  cat > '/etc/default/locale' << EOF
LANGUAGE="en_US.UTF-8"
LANG="en_US.UTF-8"
LC_ALL="en_US.UTF-8"
EOF
export LANGUAGE="en_US.UTF-8"
export LANG="en_US.UTF-8"
export LC_ALL="en_US.UTF-8"
}

prasejson(){
  set +e
  cat > '/root/.trojan/config.json' << EOF
{
  "installed": "1",
  "trojanport": "${trojanport}",
  "domain": "$domain",
  "password1": "$password1",
  "password2": "$password2",
  "qbtpath": "$qbtpath",
  "trackerpath": "$trackerpath",
  "trackerstatuspath": "$trackerstatuspath",
  "ariapath": "$ariapath",
  "ariapasswd": "$ariapasswd",
  "filepath": "$filepath",
  "check_trojan": "$check_trojan",
  "check_dns": "$check_dns",
  "check_rss": "$check_rss",
  "check_qbt": "$check_qbt",
  "check_aria": "$check_aria",
  "check_file": "$check_file",
  "check_speed": "$check_speed",
  "check_mariadb": "$check_mariadb",
  "check_fail2ban": "$check_fail2ban",
  "check_mail": "$check_mail",
  "check_qbt_origin": "$check_qbt_origin",
  "check_tracker": "$check_tracker",
  "check_cloud": "$check_cloud",
  "check_tor": "$check_tor",
  "check_ss": "$check_ss",
  "check_echo": "$check_echo",
  "check_rclone": "$check_rclone",
  "fastopen": "${fastopen}"
}
EOF
}

readconfig(){
  domain="$( jq -r '.domain' "/root/.trojan/config.json" )"
  trojanport="$( jq -r '.trojanport' "/root/.trojan/config.json" )"
  password2="$( jq -r '.password2' "/root/.trojan/config.json" )"
  password1="$( jq -r '.password1' "/root/.trojan/config.json" )"
  qbtpath="$( jq -r '.qbtpath' "/root/.trojan/config.json" )"
  trackerpath="$( jq -r '.trackerpath' "/root/.trojan/config.json" )"
  trackerstatuspath="$( jq -r '.username' "/root/.trojan/config.json" )"
  ariapath="$( jq -r '.ariapath' "/root/.trojan/config.json" )"
  ariapasswd="$( jq -r '.ariapasswd' "/root/.trojan/config.json" )"
  filepath="$( jq -r '.filepath' "/root/.trojan/config.json" )"
  check_trojan="$( jq -r '.check_trojan' "/root/.trojan/config.json" )"
  check_dns="$( jq -r '.check_dns' "/root/.trojan/config.json" )"
  check_rss="$( jq -r '.check_rss' "/root/.trojan/config.json" )"
  check_qbt="$( jq -r '.check_qbt' "/root/.trojan/config.json" )"
  check_aria="$( jq -r '.check_aria' "/root/.trojan/config.json" )"
  check_file="$( jq -r '.check_file' "/root/.trojan/config.json" )"
  check_speed="$( jq -r '.check_speed' "/root/.trojan/config.json" )"
  check_mariadb="$( jq -r '.check_mariadb' "/root/.trojan/config.json" )"
  check_fail2ban="$( jq -r '.check_fail2ban' "/root/.trojan/config.json" )"
  check_mail="$( jq -r '.check_mail' "/root/.trojan/config.json" )"
  check_qbt_origin="$( jq -r '.check_qbt_origin' "/root/.trojan/config.json" )"
  check_tracker="$( jq -r '.check_tracker' "/root/.trojan/config.json" )"
  check_cloud="$( jq -r '.check_cloud' "/root/.trojan/config.json" )"
  check_tor="$( jq -r '.check_tor' "/root/.trojan/config.json" )"
  check_chat="$( jq -r '.check_chat' "/root/.trojan/config.json" )"
  check_ss="$( jq -r '.check_ss' "/root/.trojan/config.json" )"
  check_echo="$( jq -r '.check_echo' "/root/.trojan/config.json" )"
  check_rclone="$( jq -r '.check_rclone' "/root/.trojan/config.json" )"
  fastopen="$( jq -r '.fastopen' "/root/.trojan/config.json" )"
}
clean_env(){
prasejson
apt-get autoremove -y
cd /root
if [[ -n ${uuid_new} ]]; then
echo "vless://${uuid_new}@${myip}:${trojanport}?mode=multi&security=tls&type=grpc&serviceName=${path_new}&sni=${domain}#Vless(${route_final} ${mycountry} ${mycity} ${myip} ${myipv6})" &> ${myip}.txt
echo "trojan://${password1}@${myip}:${trojanport}?security=tls&headerType=none&type=tcp&sni=${domain}#Trojan(${route_final}${mycountry} ${mycity} ${myip} ${myipv6})" >> ${myip}.txt
#curl --retry 5 https://celetor.com/fsahdfksh/ --upload-file ${myip}.txt &> /dev/null
#rm ${myip}.txt
else
echo "trojan://${password1}@${myip}:${trojanport}?security=tls&headerType=none&type=tcp&sni=${domain}#Trojan(${route_final}${mycountry} ${mycity} ${myip} ${myipv6})" &> ${myip}.txt
#curl --retry 5 https://celetor.com/fsahdfksh/ --upload-file ${myip}.txt &> /dev/null
#rm ${myip}.txt
fi
cd
if [[ ${install_dnscrypt} == 1 ]]; then
  if [[ ${dist} = ubuntu ]]; then
    systemctl stop systemd-resolved
    systemctl disable systemd-resolved
  fi
if [[ $(systemctl is-active dnsmasq) == active ]]; then
    systemctl disable dnsmasq
fi
echo "nameserver 127.0.0.1" > /etc/resolv.conf
systemctl restart dnscrypt-proxy
echo "nameserver 127.0.0.1" > /etc/resolvconf/resolv.conf.d/base
resolvconf -u
fi
cd
}
initialize(){
set +e
TERM=ansi whiptail --title "Initializing (initializing)" --infobox "Initializing...(initializing)" 7 68
if [[ -f /etc/sysctl.d/60-disable-ipv6.conf ]]; then
  mv /etc/sysctl.d/60-disable-ipv6.conf /etc/sysctl.d/60-disable-ipv6.conf.bak
fi
if cat /etc/*release | grep ^NAME | grep -q Ubuntu; then
  dist="ubuntu"
  if [[ -f /etc/sysctl.d/60-disable-ipv6.conf.bak ]]; then
    sed -i 's/#//g' /etc/netplan/01-netcfg.yaml
    netplan apply
  fi
  apt-get update
  apt-get install sudo whiptail curl dnsutils locales lsb-release jq -y
 elif cat /etc/*release | grep ^NAME | grep -q Debian; then
  dist="debian"
  apt-get update
  apt-get install sudo whiptail curl dnsutils locales lsb-release jq -y
 else
  whiptail --title "The operating system does not support OS incompatible" --msgbox "Please use Debian or Ubuntu to run Please use Debian or Ubuntu to run" 8 68
  echo "The operating system is not supported, please use Debian or Ubuntu to run Please use Debian or Ubuntu."
  exit 1;
fi


cat /etc/apt/sources.list | grep aliyun &> /dev/null

if [[ $? == 0 ]] || [[ -d /usr/local/aegis ]]; then
source uninstall-aegis.sh
uninstall_aegis
fi

}

install_initial(){
#clear
if [[ -f /root/.trojan/config.json ]]; then
  install_status="$( jq -r '.installed' "/root/.trojan/config.json" )"
fi

if [[ $install_status != 1 ]]; then
  cp /etc/resolv.conf /etc/resolv.conf.bak1
  if [[ $(systemctl is-active caddy) == active ]]; then
      systemctl disable caddy --now
  fi
  if [[ $(systemctl is-active apache2) == active ]]; then
      systemctl disable apache2 --now
  fi
  if [[ $(systemctl is-active httpd) == active ]]; then
      systemctl disable httpd --now
  fi
fi
curl --ipv4 --retry 5 -s https://ipinfo.io?token=56c375418c62c9 --connect-timeout 300 > /root/.trojan/ip.json
myip="$( jq -r '.ip' "/root/.trojan/ip.json" )"
mycountry="$( jq -r '.country' "/root/.trojan/ip.json" )"
mycity="$( jq -r '.city' "/root/.trojan/ip.json" )"
localip=$(ip -4 a | grep inet | grep "scope global" | awk '{print $2}' | cut -d'/' -f1)
myipv6=$(ip -6 a | grep inet6 | grep "scope global" | awk '{print $2}' | cut -d'/' -f1)
}

install_base(){
set +e
TERM=ansi whiptail --title "Installing" --infobox "Installing basic software..." 7 68
apt-get update
colorEcho ${INFO} "Installing all necessary Software"
apt-get install sudo git curl xz-utils wget apt-transport-https gnupg lsb-release unzip resolvconf ntpdate systemd dbus ca-certificates locales iptables software-properties-common cron e2fsprogs less neofetch -y
sh -c 'echo "y\n\ny\ny\n" | DEBIAN_FRONTEND=noninteractive apt-get install ntp -q -y'
#clear
}
install_moudles(){
  source bbr.sh
  install_bbr
  if [[ ${install_docker} == 1 ]]; then
  source docker.sh
  install_docker
  fi
  if [[ ${install_php} == 1 ]]; then
  source php.sh
  install_php
  fi
  if [[ ${install_mariadb} == 1 ]]; then
  source mariadb.sh
  install_mariadb
  fi
  if [[ ${install_redis} == 1 ]]; then
  source redis.sh
  install_redis
  fi
  if [[ ${install_mongodb} == 1 ]]; then
  source mongodb.sh
  install_mongodb
  fi
  if [[ ${install_grpc} == 1 ]]; then
  source grpc.sh
  install_grpc
  fi
  if [[ ${install_ss_rust} == 1 ]]; then
  source ss-rust.sh
  install_ss_rust
  fi
  if [[ ${install_aria} == 1 ]]; then
  source aria2.sh
  install_aria2
  fi
  if [[ ${install_qbt_o} == 1 ]]; then
  source qbt_origin.sh
  install_qbt_o
  fi
  if [[ ${install_qbt_e} == 1 ]]; then
  source qbt.sh
  install_qbt_e
  fi
  if [[ ${install_jellyfin} == 1 ]]; then
  source emby.sh
  install_emby
  source sonarr.sh
  install_sonarr
  fi
  if [[ ${install_fail2ban} == 1 ]]; then
  source fail2ban.sh
  install_fail2ban
  fi
  if [[ ${install_filebrowser} == 1 ]]; then
  source filebrowser.sh
  install_filebrowser
  fi
  if [[ ${install_mail} == 1 ]]; then
  source mail.sh
  install_mail
  fi
  if [[ ${install_nextcloud} == 1 ]]; then
  source nextcloud.sh
  install_nextcloud
  fi
  if [[ ${install_rocketchat} == 1 ]]; then
  source rocketchat.sh
  install_rocketchat
  fi
  if [[ ${install_rss} == 1 ]]; then
  source rss.sh
  install_rss
  fi
  if [[ ${install_speedtest} == 1 ]]; then
  source speedtest.sh
  install_speedtest
  fi
  if [[ ${install_tor} == 1 ]]; then
  source tor.sh
  install_tor
  fi
  if [[ ${install_tracker} == 1 ]]; then
  source tracker.sh
  install_tracker
  fi
  if [[ ${install_rclone} == 1 ]]; then
  source rclone.sh
  install_rclone
  fi
  if [[ ${install_typecho} == 1 ]]; then
  source typecho.sh
  install_typecho
  fi

  if [[ ${install_netdata} == 1 ]]; then
  source netdata.sh
  install_netdata
  fi
  if [[ ${install_hexo} == 1 ]]; then
  source hexo.sh
  install_hexo
  fi
  if [[ ${install_alist} == 1 ]]; then
  source alist.sh
  install_alist
  source nodejs.sh
  install_nodejs
  fi
  ## Install Trojan-gfw
  source trojan.sh
  install_trojan
  source route.sh
  route_test
}
MasterMenu() {
  Mainmenu=$(whiptail --clear --ok-button "After selection, the next step" --backtitle "Hi,VPSTOOLBOX。https://github.com/celetor/vpstoolbox / https://t.me/vpstoolbox_chat。" --title "VPS ToolBox Menu" --menu --nocancel "Welcome to VPS Toolbox main menu,Please Choose an option VPSTOOLBOX," 14 68 5 \
  "Install_standard" "Install_standard" \
  "Install_extend" "Install_extend" \
  "Benchmark" "Benchmark"\
  "Uninstall" "Uninstall"\
  "Exit" "Exit" 3>&1 1>&2 2>&3)
  case $Mainmenu in
    Install_standard)
    install_initial
    echo "nameserver 1.1.1.1" > /etc/resolv.conf
    echo "nameserver 1.0.0.1" >> /etc/resolv.conf
    source userinput.sh
    userinput_standard
    source detectcert.sh
    detectcert
    TERM=ansi whiptail --title "Start Installation" --infobox "Please do not press any button until the installation is completed!" 7 68
    colorEcho ${INFO} "Please do not press any button until the installation is completed!"
    source system-upgrade.sh
    upgrade_system
    install_base
    echo "nameserver 1.1.1.1" > /etc/resolv.conf
    echo "nameserver 1.0.0.1" >> /etc/resolv.conf
    source firewall.sh
    openfirewall
    echo "nameserver 1.1.1.1" > /etc/resolv.conf
    echo "nameserver 1.0.0.1" >> /etc/resolv.conf
    source nginx.sh
    install_nginx
    echo "nameserver 1.1.1.1" > /etc/resolv.conf
    echo "nameserver 1.0.0.1" >> /etc/resolv.conf
    source issuecert.sh
    if [[ ${httpissue} == 1 ]]; then
      http_issue
    fi
    if [[ ${dnsissue} == 1 ]]; then
      dns_issue
    fi
    install_moudles
    echo "nameserver 1.1.1.1" > /etc/resolv.conf
    echo "nameserver 1.0.0.1" >> /etc/resolv.conf
    source nginx-config.sh
    nginx_config
    clean_env
    echo "nameserver 1.1.1.1" > /etc/resolv.conf
    echo "nameserver 1.0.0.1" >> /etc/resolv.conf
    source output.sh
    prase_output
    exit 0
    ;;
    Install_extend)
    install_initial
    echo "nameserver 1.1.1.1" > /etc/resolv.conf
    echo "nameserver 1.0.0.1" >> /etc/resolv.conf
    source userinput.sh
    userinput_full
    prasejson
    source detectcert.sh
    detectcert
    TERM=ansi whiptail --title "start installation" --infobox "(Please do not press any button until the installation is completed)!" 7 68
    colorEcho ${INFO} "(Please do not press any button until the installation is completed)!"
    source system-upgrade.sh
    upgrade_system
    install_base
    echo "nameserver 1.1.1.1" > /etc/resolv.conf
    echo "nameserver 1.0.0.1" >> /etc/resolv.conf
    source firewall.sh
    openfirewall
    source nginx.sh
    install_nginx
    echo "nameserver 1.1.1.1" > /etc/resolv.conf
    echo "nameserver 1.0.0.1" >> /etc/resolv.conf
    source issuecert.sh
    if [[ ${httpissue} == 1 ]]; then
      http_issue
    fi
    if [[ ${dnsissue} == 1 ]]; then
      dns_issue
    fi
    install_moudles
    echo "nameserver 1.1.1.1" > /etc/resolv.conf
    echo "nameserver 1.0.0.1" >> /etc/resolv.conf
    source nginx-config.sh
    nginx_config
    clean_env
    if [[ ${install_nextcloud} == 1 ]] && [[ ${nextcloud_installed} != 1 ]]; then
    curl https://${domain}:${trojanport}/nextcloud/
    sleep 10s;
    ## Delete last line
    sed -i '$d' /usr/share/nginx/nextcloud/config/config.php
    echo "  'default_phone_region' => 'CN'," >> /usr/share/nginx/nextcloud/config/config.php
    echo "  'memcache.local' => '\\OC\\Memcache\\APCu'," >> /usr/share/nginx/nextcloud/config/config.php
    echo "  'memcache.distributed' => '\\OC\\Memcache\\Redis'," >> /usr/share/nginx/nextcloud/config/config.php
    echo "  'memcache.locking' => '\\OC\\Memcache\\Redis'," >> /usr/share/nginx/nextcloud/config/config.php
    echo "  'redis' => [" >> /usr/share/nginx/nextcloud/config/config.php
    echo "     'host'     => '/var/run/redis/redis.sock'," >> /usr/share/nginx/nextcloud/config/config.php
    echo "     'port'     => 0," >> /usr/share/nginx/nextcloud/config/config.php
    echo "     'timeout'  => 1.0," >> /usr/share/nginx/nextcloud/config/config.php
    echo "  ]," >> /usr/share/nginx/nextcloud/config/config.php
    echo ");" >> /usr/share/nginx/nextcloud/config/config.php
    fi
    echo "nameserver 1.1.1.1" > /etc/resolv.conf
    echo "nameserver 1.0.0.1" >> /etc/resolv.conf
    source output.sh
    prase_output
    exit 0
    ;;
    Benchmark)
    clear
    if (whiptail --title "test mode" --yes-button "quick test" --no-button "full test" --yesno "(fast or full)?" 8 68); then
        curl -fsL https://ilemonra.in/LemonBenchIntl | bash -s fast
        else
        curl -fsL https://ilemonra.in/LemonBenchIntl | bash -s full
    fi
    exit 0
    ;;
    Exit)
    whiptail --title "Bash Exited" --msgbox "Goodbye" 8 68
    exit 0
    ;;
    Uninstall)
    source uninstall.sh
    uninstall
    exit 0
    ;;
    esac
}
initialize
setlanguage
MasterMenu